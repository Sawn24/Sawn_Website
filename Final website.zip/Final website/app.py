# Importing the necessary flask modules for SAWN project  
# An object of Flask class is our WSGI application.
from flask import Flask
from flask import render_template
from flask import request
import sqlite3
from flask import redirect, url_for
import random
from datetime import datetime
from flask import jsonify   

# Flask constructor takes the name of 
# current module (__name__) as argument.
app = Flask(__name__, static_url_path='/static')

# This route takes the basick page of our sawn website
@app.route("/")
def Landing():
    return render_template("Landing.html")

# This render sent the html as url at any html emlement invoke it
@app.route("/Admin")
def Admin():
    return render_template("Admin.html")

# This render sent the html as url at any html emlement invoke it
@app.route("/Guest")
def Guest():
    return render_template("Guest.html")

# This render sent the html as url at any html emlement invoke it
@app.route("/Livestream")
def Livestream():
    
     # Connect to the SQLite3 datatabase and 
    # SELECT rowid and all Rows from the Violation table.
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()

    cursor.execute("""
     SELECT Camera.Cam_ID, Camera.Cam_IP, Camera.Location
     FROM Camera 
     
        """)
    rows = cursor.fetchall()

    

    connection.close()
    # Send the results of the SELECT to the Home-page.html page 
    return render_template("Livestream.html",rows=rows,username=username)




@app.route('/IPsearch', methods=['POST'])
def IPsearch():
    if request.method == 'POST':
        selected_IPs = request.json.get('cameraIP')

        connection = sqlite3.connect('SAWN_db.db')
        connection.row_factory = sqlite3.Row
        cursor = connection.cursor()

        query = """
            SELECT Camera.Cam_ID, Camera.Location, Camera.Cam_IP, Livestream.Livestream_ID,
                   Livestream.Duration, Livestream.Date, Livestream.Time, Livestream.Num_of_Violation
            FROM Camera
            JOIN Livestream ON Camera.Cam_ID = Livestream.Cam_ID
            WHERE Camera.Cam_IP = ?  
            """

        data = []
        for ip in selected_IPs:
            cursor.execute(query, (ip,))
            rows = cursor.fetchall()
            data.extend([dict(row) for row in rows])

        connection.close()

        return jsonify(data)



@app.route("/GuestViolation", methods=['POST'])
def GuestViolationDetails():
     if request.method == 'POST':
        Ticket_ID = request.form['TicketID']
        print("Ticket_ID:", type(Ticket_ID))
        Ticket_ID=int(Ticket_ID)
        print("Ticket_ID:", type(Ticket_ID))

 
        # Connect to the SQLite3 datatabase and 
        # SELECT rowid and all Rows from the Violation table.
        connection=sqlite3.connect('SAWN_db.db')
        connection.row_factory = sqlite3.Row
        cursor = connection.cursor()
        cursor.execute("""
       SELECT 
        Ticket.Ticket_ID, 
        Ticket.Violation_type, 
        Ticket.Video_Path, 
        Camera.Location, 
        Ticket.Date, 
        Ticket.Time,
        Pedestrian.Face_Image,
        Vehicle.Plate_No                             
         FROM Ticket 
         JOIN Camera ON Ticket.Livestream_ID = Camera.Cam_ID
        LEFT JOIN Pedestrian ON Ticket.Ticket_ID = Pedestrian.Violation_ID
        LEFT JOIN Vehicle ON Ticket.Ticket_ID = Vehicle.Violation_ID
        WHERE Ticket.Ticket_ID = ?
        """, (Ticket_ID,))


         # Fetch all rows and serialize them into a list of dictionaries
        data = [dict(row) for row in cursor.fetchall()]
        
        #data = cursor.fetchall()
        # Close the database connection
        connection.close()
            
        
         
              
        print(data[0]['Ticket_ID'])
        print(data[0]['Violation_type'])
        print(data[0]['Location'])
        print(data[0]['Date'])
        print(data[0]['Time'])
        print(data[0]['Video_Path'])
        print(data[0]['Face_Image'])
        print(data[0]['Plate_No'])
       
                  

        
            
          
        # Send the results of the SELECT to the Guest.html page 
        #return render_template('Guest.html',data=data)
        # Return the data as JSON response
        return jsonify(data)


# Route for rendering the HTML template
@app.route("/HomePage")
def HomePage():
    # Connect to the SQLite3 datatabase and 
    # SELECT rowid and all Rows from the Violation table.
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()
    cursor.execute("""
     SELECT Violation.Violation_ID,Violation.Violation_type, Violation.Date, Violation.Time, Livestream.Cam_ID, Violation.Video_Path
     FROM Violation
     JOIN Livestream ON Violation.Livestream_ID = Livestream.Livestream_ID
        """)
    rows = cursor.fetchall()
    connection.close()
    # Send the results of the SELECT to the Home-page.html page 

    return render_template("Home-page.html", rows=rows,username=username)



@app.route("/TicketPage")
def TicketPage():
    # Connect to the SQLite3 datatabase and 
    # SELECT rowid and all Rows from the Violation table.
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()

    '''
    Ticket_ID INTEGER PRIMARY KEY,
    Date TEXT NOT NULL,
    Time TEXT NOT NULL,
    Close_Date TEXT NOT NULL,
    Status TEXT NOT NULL,
    Violation_type TEXT NOT NULL,
    Video_Path TEXT NOT NULL,
    Livestream_ID INTEGER NOT NULL,
    Admin_ID INTEGER NOT NULL,
    Violation_ID INTEGER NOT NULL
'''
    cursor.execute("""
     SELECT Ticket.Ticket_ID, Ticket.Date, Ticket.Time, Ticket.Close_Date ,Ticket.Status , Ticket.Violation_type ,Ticket.Video_Path , Ticket.Livestream_ID, Ticket.Admin_ID ,Ticket.Violation_ID, Pedestrian.Face_Image , Vehicle.Plate_No
     FROM Ticket
     LEFT JOIN Pedestrian ON Ticket.Ticket_ID = Pedestrian.Violation_ID
     LEFT JOIN Vehicle ON Ticket.Ticket_ID = Vehicle.Violation_ID
     Where Ticket.Status = 'Open'            
        """)
    rows = cursor.fetchall()
    
    cursor.execute("""
     SELECT Ticket.Ticket_ID, Ticket.Date, Ticket.Time, Ticket.Close_Date ,Ticket.Status , Ticket.Violation_type ,Ticket.Video_Path , Ticket.Livestream_ID, Ticket.Admin_ID ,Ticket.Violation_ID ,Pedestrian.Face_Image , Vehicle.Plate_No
     FROM Ticket
     LEFT JOIN Pedestrian ON Ticket.Ticket_ID = Pedestrian.Violation_ID
     LEFT JOIN Vehicle ON Ticket.Ticket_ID = Vehicle.Violation_ID
     Where Ticket.Status = 'Closed'            
        """)
    rows2 = cursor.fetchall()
    connection.close()
    # Send the results of the SELECT to the Home-page.html page 

    return render_template("Ticket-page.html", rows=rows,rows2=rows2,username=username)


#Login to sawn website
@app.route("/Login", methods=['GET','POST'])
def Login():
    global username
    if request.method=='POST':
        #-----------------------------------------------
        #SQLite
        connection=sqlite3.connect('SAWN_db.db')
        cursor=connection.cursor()
        #-----------------------------------------------
        #HTML FORM
        username=request.form['username']
        password=request.form['password']
        print(username,password)
        #-----------------------------------------------
        # Query to select username and password from the Admin table
        query = "SELECT User_Name, Password FROM Admin WHERE User_Name = ? AND Password = ?"

        # Execute the query with provided username and password
        cursor.execute(query, (username, password))
        #result = cursor.fetchone() when you expect multiple rows (return 'None')
        #result = cursor.fetchall() when you expect only one row  (return [])
        result = cursor.fetchall() 
        
        if len(result)==0: # check if result null, no  username and password  are matching
            #Login failed
            message = 'Invalid username or password'
            return render_template("Admin.html",message=message)
        
        # Close database connection
        connection.close()
        #-----------------------------------------------
        # Connect to the SQLite3 datatabase  
        # SELECT all Rows from the Violation table.
        connection=sqlite3.connect('SAWN_db.db')
        connection.row_factory = sqlite3.Row

        cursor = connection.cursor()
        cursor.execute("""
        SELECT Violation.Violation_ID,Violation.Violation_type,Pedestrian.Face_Image,
        Vehicle.Plate_No, Violation.Date, Violation.Time, Livestream.Cam_ID, Violation.Video_Path
        FROM Violation
        JOIN Livestream ON Violation.Livestream_ID = Livestream.Livestream_ID
        LEFT JOIN Pedestrian ON Violation.Violation_ID = Pedestrian.Violation_ID
        LEFT JOIN Vehicle ON Violation.Violation_ID = Vehicle.Violation_ID                           
        """)
        rows = cursor.fetchall()
        connection.close()
        # Check if data was correctly retrieved
        if rows:
        # Data was retrieved, print the rows
          for row in rows:
              print(row['Violation_ID'])
              print(row['Violation_type'])
              print(row['Face_Image'])
              print(row['Plate_No'])
              print(row['Date'])
              print(row['Time'])
              print(row['Cam_ID'])
              print(row['Video_Path'])
        else:
         print("No data found")
        # Send the results of the SELECT to the list.html page     
    return render_template("Home-page.html",rows=rows,username=username)  





@app.route("/AdminInformation/<username>", methods=["GET"])
def AdminInformation(username):
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()

    '''
    cursor.execute("""
     SELECT *
     FROM Admin 
     Where User_Name = username  
        """)
    '''

    cursor.execute( """ 
     SELECT *
    FROM Admin
    WHERE User_Name = (?)""", (username,)) 
    
    row = cursor.fetchone()
    connection.close()
    '''
              Admin_ID INTEGER PRIMARY KEY,
              First_Name TEXT NOT NULL,
              Last_Name TEXT NOT NULL,
              Email TEXT NOT NULL,
               User_Name TEXT NOT NULL,
              Password TEXT NOT NULL,
              Phone_No INTEGER NOT NULL
             
             '''
   
    return render_template("AdminInformation.html",row=row)



@app.route("/EditAdmin", methods=['GET', 'POST'])
def EditAdmin():
     if request.method == 'POST':
        Email = request.form.get('Email')
        print(Email)
        Username = request.form.get('Username')
        Firstname = request.form.get('Firstname')
        Lastname = request.form.get('Lastname')
        Phonenumber = request.form.get('Phonenumber')
        Password = request.form.get('Password')
        
        # Proceed with inserting the record into the database
        connection = sqlite3.connect('SAWN_db.db')
        cursor = connection.cursor()
        cursor.execute("INSERT INTO Admin (Email, User_Name, First_Name, Last_Name, Phone_No, Password) VALUES (?, ?, ?, ?, ?, ?)",
                       (Email, Username, Firstname, Lastname, Phonenumber, Password))
        connection.commit()
        connection.close()
        
        return redirect(url_for('AdminInformation',username=username))








@app.route('/submitTicket', methods=['POST'])
def submit_ticket():
 if request.method == 'POST':
    # Get the list of selected row IDs from the form as string
    selected_violations = request.form.getlist('selected_violations[]')
    # Convert data into integer
    selected_violations = [int(value) for value in request.form.getlist('selected_violations[]')]

    # Iterate over the selected row IDs
    for row_id in selected_violations:
        print(row_id,type(row_id))
        # Perform actions for each selected row ID
        # For example, update the corresponding records in the database
        # For example, update the corresponding records in the database
    #-----------------------------------------------
    #SQLite
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row  # Set row factory to return dictionaries
    cursor=connection.cursor()
    #-----------------------------------------------
    #insert ticket query 
    insert_ticket_query = """
     INSERT INTO 
     Ticket (Ticket_ID, Violation_type, Video_Path, Date, Time, Close_Date, Admin_ID, Livestream_ID, Violation_ID)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
    """
    #-----------------------------------------------
    # Retrieve necessary Data
    # 1- Retrieve all Admin IDs from the Admin table
    cursor.execute("SELECT Admin_ID FROM Admin")
    admin_ids = [row['Admin_ID'] for row in cursor.fetchall()]
    print(admin_ids)
    
    # Execute the insert query for each selected violation
    for violation_id in selected_violations:
        # Randomly select one Admin ID
        admin_id = random.choice(admin_ids)
        Ticket_ID = violation_id
         
        cursor.execute("SELECT Date,Time,Violation_type,Video_Path, Livestream_ID FROM Violation WHERE Violation_ID = ?", (violation_id,))
        row = cursor.fetchall()
        print(row[0]['Date'])
        print(row[0]['Time'])
        if len(row)!=0:  # Check if a row is returned
            date, time,Violation_type,Video_Path,Livestream_ID =row[0]['Date'],row[0]['Time'],row[0]['Violation_type'],row[0]['Video_Path'],row[0]['Livestream_ID']  # Access values using keys
        close_date = datetime.now().date()
        admin_id = random.choice(admin_ids)
        cursor.execute(insert_ticket_query, (Ticket_ID,Violation_type,Video_Path, date, time, close_date, admin_id,Livestream_ID, violation_id))
       
        delete_violation_query = "DELETE FROM Violation WHERE Violation_ID = ?"
        # Execute the query
        cursor.execute(delete_violation_query, (violation_id,)) 
    # Commit changes if using SQLite
    connection.commit()

    # Close the connection
    connection.close()
    # Define success message
    success_message = "Tickets have been successfully sent and are currently being processed. For the latest status update, please visit the Tickets page."
    # Connect to the SQLite3 datatabase and 
    # SELECT rowid and all Rows from the Violation table.
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()
    cursor.execute("""
        SELECT Violation.Violation_ID,Violation.Violation_type, Violation.Date, Violation.Time, Livestream.Cam_ID, Violation.Video_Path
        FROM Violation
        JOIN Livestream ON Violation.Livestream_ID = Livestream.Livestream_ID
        """)
    rows = cursor.fetchall()
    connection.close()    
    # Return success message as JSON response
    return render_template('Home-page.html',rows=rows,success_message=success_message)
 


@app.route('/CameraSetting')
def CameraSetting():
     # Connect to the SQLite3 datatabase and 
    # SELECT rowid and all Rows from the Violation table.
    connection=sqlite3.connect('SAWN_db.db')
    connection.row_factory = sqlite3.Row

    cursor = connection.cursor()
    cursor.execute("""
     SELECT *
     FROM Camera
        """)
    rows = cursor.fetchall()
    connection.close()
    # Send the results of the SELECT to the Home-page.html page 
    return render_template('Camera-Setting.html',rows=rows,username=username)

def get_next_camera_id():
    connection = sqlite3.connect('SAWN_db.db')
    cursor = connection.cursor()
    cursor.execute("SELECT MAX(Cam_ID) FROM Camera")
    last_id = cursor.fetchone()[0]
    connection.close()
    if last_id:
        return last_id + 1
    else:
        return 1

@app.route("/AddNewCamera", methods=['GET', 'POST'])
def AddNewCamera():
    if request.method == 'POST':
        cam_ip = request.form.get('cam_ip')
        frame_rate = request.form.get('frame_rate')
        resolution = request.form.get('resolution')
        location_link = request.form.get('location_link')
        city = request.form.get('city')
        
        cam_id = get_next_camera_id()

        # Proceed with inserting the record into the database
        connection = sqlite3.connect('SAWN_db.db')
        cursor = connection.cursor()
        cursor.execute("INSERT INTO Camera (Cam_ID, Cam_IP, Status, Frame_Rate, Resolution, Location, City) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       (cam_id, cam_ip, 'Active', frame_rate, resolution, location_link, city))
        connection.commit()
        connection.close()

        
        return redirect(url_for('CameraSetting'))


def update_camera(cam_id, cam_ip, frame_rate, resolution, location_link, city):
    connection=sqlite3.connect('SAWN_db.db')
    cursor = connection.cursor()
    cursor.execute("UPDATE Camera SET Cam_IP=?,Status=?, Frame_Rate=?, Resolution=?, Location=?, City=? WHERE Cam_ID=?",
                   (cam_ip,'Active',frame_rate, resolution, location_link, city, cam_id))
    connection.commit()
    connection.close()

@app.route("/EditCamera", methods=['POST'])
def edit_camera():
    if request.method == 'POST':
        cam_id = request.form.get('cam_id')
        cam_ip = request.form.get('cam_ip')
        frame_rate = request.form.get('frame_rate')
        resolution = request.form.get('resolution')
        location_link = request.form.get('location_link')
        city = request.form.get('city')
        
        # Update the camera information in the database
        update_camera(cam_id, cam_ip, frame_rate, resolution, location_link, city)
        
        # Redirect the user to another page after editing the camera information
        return redirect(url_for('CameraSetting'))

@app.route("/DeleteCameras", methods=['POST'])
def delete_cameras():
    if request.method == 'POST':
        # Get the list of selected camera IDs from the form
        selected_cameras = request.form.getlist('selected_cameras[]')

        # Convert camera IDs to integers
        selected_cameras = [int(cam_id) for cam_id in selected_cameras]

        # Connect to the database
        connection = sqlite3.connect('SAWN_db.db')
        cursor = connection.cursor()

        # Delete the selected cameras from the database
        for cam_id in selected_cameras:
            cursor.execute("DELETE FROM Camera WHERE Cam_ID = ?", (cam_id,))
        
        # Commit changes and close the connection
        connection.commit()
        connection.close()

        # Redirect the user to another page after deleting the cameras
        return redirect(url_for('CameraSetting'))

    # Handle other HTTP methods or invalid requests
    return "Invalid request", 400


