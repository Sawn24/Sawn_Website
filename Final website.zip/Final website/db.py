import sqlite3
from datetime import datetime

# Connect to the SQLite database file
conn = sqlite3.connect('SAWN_db.db')

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Define SQL queries to create tables
create_Admin_table_query = """
CREATE TABLE IF NOT EXISTS Admin (
    Admin_ID INTEGER PRIMARY KEY,
    First_Name TEXT NOT NULL,
    Last_Name TEXT NOT NULL,
    Email TEXT NOT NULL,
    User_Name TEXT NOT NULL,
    Password TEXT NOT NULL,
    Phone_No INTEGER NOT NULL
)
"""

  
create_Camera_table_query = """
CREATE TABLE IF NOT EXISTS Camera (
    Cam_ID INTEGER PRIMARY KEY,
    Cam_IP TEXT NOT NULL,
    Status TEXT NOT NULL,
    Frame_Rate TEXT NOT NULL,
    Resolution TEXT NOT NULL,
    Location TEXT NOT NULL,
    City TEXT NOT NULL
)
"""
 
create_Livestream_table_query = """
CREATE TABLE IF NOT EXISTS Livestream (
  Livestream_ID INTEGER PRIMARY KEY,
  Duration REAL NOT NULL,
  Date DATE NOT NULL,
  Time TIME NOT NULL,
  Cam_ID INTEGER NOT NULL UNIQUE,  
  Num_of_Violation INTEGER NOT NULL,
  FOREIGN KEY (Cam_ID) REFERENCES Camera(Cam_ID)  
)
"""
 
create_Violation_table_query = """
CREATE TABLE IF NOT EXISTS Violation (
    Violation_ID INTEGER PRIMARY KEY,
    Violation_type TEXT NOT NULL,
    Video_Path TEXT NOT NULL,
    Date DATE NOT NULL,
    Time TIME NOT NULL,
    Livestream_ID INTEGER NOT NULL
)
"""
 # ✔ (Violation_type, Video_Path from violation) Added by GHADAH
create_Ticket_table_query = """
CREATE TABLE IF NOT EXISTS Ticket (
    Ticket_ID INTEGER PRIMARY KEY,
    Date TEXT NOT NULL,
    Time TEXT NOT NULL,
    Close_Date TEXT NOT NULL,
    Status TEXT NOT NULL,
    Violation_type TEXT NOT NULL,
    Video_Path TEXT NOT NULL,
    Livestream_ID INTEGER NOT NULL,
    Admin_ID INTEGER NOT NULL,
    Violation_ID INTEGER NOT NULL
)
"""


create_camera_manage_table_query = """
CREATE TABLE IF NOT EXISTS camera_manage (
    Admin_ID INTEGER NOT NULL,
    Cam_ID INTEGER NOT NULL
)
"""
create_violation_manage_table_query = """
CREATE TABLE IF NOT EXISTS violation_manage (
    Admin_ID INTEGER NOT NULL,
    Violation_ID INTEGER NOT NULL
    )"""

 

#🛑image data   
create_Pedestrian_table_query = """
CREATE TABLE IF NOT EXISTS Pedestrian (
    Violation_ID INTEGER NOT NULL,
    Face_Image TEXT NOT NULL
)
"""
#🛑image data  
create_Vehicle_table_query = """
CREATE TABLE IF NOT EXISTS Vehicle (
    Violation_ID INTEGER NOT NULL,
    Plate_No TEXT NOT NULL
)
"""
  
 
 
# Execute the SQL queries to create tables
cursor.execute(create_Admin_table_query)
cursor.execute(create_Camera_table_query)
cursor.execute(create_Livestream_table_query) 
cursor.execute(create_Violation_table_query) 
cursor.execute(create_Ticket_table_query)
cursor.execute(create_camera_manage_table_query)
cursor.execute(create_violation_manage_table_query)
 
#🛑 create table after check
cursor.execute(create_Pedestrian_table_query)
cursor.execute(create_Vehicle_table_query)
 
 
 

# Define data to insert into the Admin table
# Admin_ID INTEGER, First_Name TEXT,Last_Name TEXT,Email TEXT, Password TEXT, Phone_No TEXT 
Admin_data = [ 
(1, 'Ahmed', 'Alshumrani', 'AhmAlsh@gmail.com','1214567','AA@231372','0566726531'),
(2, 'Fatima', 'Nasser', 'FatimaNasser@hotmail.com','8901234','FN@193256','0578183498'),
(3, 'Mohammed', 'Abdullah', 'Mohammad_Abdullah_97@gmail.com','5688901','MA@123112','0549876121'),
(4, 'Aisha', 'Ali', 'AishaAli95@yahoo.com','2345178','AA@2762089','0551234567'),
(5, 'Yousef', 'Saeed', 'YousefSaeed@gmail.com','9012845','YS@231292','0556785123'),
(6, 'Sara', 'Ahmed', 'SaraAhmed23@hotmail.com','6729012','SA@345291','0587652321'),
(7, 'Abdulaziz', 'Khalid', 'AzizKhalid@gmail.com','6989012','AK@036732','0561231890'),
(8, 'Layla', 'Hamad', 'Layla_Hamad_12@yahoo.com','1456789','LH@387252','0523567891'),
(9, 'Khalid', 'Almarzouqi', 'KhalidM1@yahoo.com','0123456','KM@293648','0508765422'),
(10, 'Noura', 'Saleh', 'Noura_Alzahrani@hotmail.com','7290123','NS@956239','0543210917'),
(11, 'Mansoor', 'Ahmed', 'MansoorAhmed@gmail.com','4867890','MA@324851','0578901234'),
(12, 'Huda', 'Ali', 'Huda_Ali@yahoo.com','1294567','HA@000123','0512340678'),
(13, 'Fahad', 'Salem', 'FahadSalem@hotmail.com','8911234','FS@122983','0567890123'),
(14, 'Reem', 'Omar', 'Reem_Omar@gmail.com','5678903','RO@654321','0532109976'),
(15, 'Saud', 'Nasser', 'Saud_Nasser@yahoo.com','5678902','SN@2012333','0582012345'),
(16, 'Noor', 'Abdulrahman', 'NoorA@hotmail.com','2345618','NA@654237','0556789012'),
(17, 'Rashid', 'Saleh', 'RashidSaleh@gmail.com','9012345','RS@348298','0523452789'),
(18, 'Lina', 'Khalifa', 'LinaKhalifa@hotmail.com','6709012','LK@378562','0578901244'),
(19, 'Khaled', 'Saeed', 'KhaledSaeed@gmail.com','3456799','KS@452341','0542210987'),
(20, 'Amal', 'Ahmed', 'AmalAhmed@yahoo.com','0113456','AA@673241','0509896543'),
(21, 'Yousef', 'Alotaibi', 'YousefAl@gmail.com','0223456','YA@298753','0567123456'),
(22, 'Hanan', 'Mohammed', 'HananM@yahoo.com','7890122','HM@231455','0578234667'),
(23, 'Sultan', 'Ahmed', 'SultanAhmed@gmail.com','7590123','SA@345621','0549745678'),
(24, 'Nadia', 'Khalid', 'NadiaK@yahoo.com','4567890','NK@234190','0501456779'),
(25, 'Mona', 'Abdulaziz', 'MonaA@hotmail.com','7890121','MA@458721','0556563890'),
(26, 'Abdullah', 'Saeed', 'AbdullahS@gmail.com','6689012','AS@000891','0587678201'),
(27, 'Layla', 'Nasser', 'LaylaNasser@hotmail.com','2345678','LN@280280','0561890143'),
(28, 'Khalid', 'Saleh', 'KhalidSaleh@gmail.com','8701234','KS@6542456','0534142456'),
(29, 'Fatima', 'Ali', 'FatimaAli@yahoo.com','3456789','FA@333422','0509874543'),
(30, 'Ahmed', 'Khalifa', 'AhmedKhalifa@gmail.com','7900123','AK@801432','0546589012'),
# Add more data as needed
]


# Define data to insert into the Camera table
# Cam_ID INTEGER, Cam_IP TEXT,Status TEXT,Frame_Rate TEXT,Resolution TEXT,Location TEXT,City TEXT
#🛑 ADD camera location link 
Camera_data = [ 
(1, '192.168.0.1','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(2, '192.168.1.1','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(3, '192.168.1.2','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(4, '192.168.1.3','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(5, '192.168.1.4','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(6, '192.168.1.5','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(7, '192.168.1.6','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(8, '192.168.1.7','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(9, '192.168.1.8','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(10,'192.168.1.9','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(11,'192.168.1.10','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(12,'192.168.1.11','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(13,'192.168.1.12','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
(14,'192.168.1.13','Active','30 fbs','5MP','https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d37272.512311111816!2d39.0775695197537!3d21.61573165768223!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x15c3dbfc795ce3f5%3A0x4d5485232f635535!2sWaterfront!5e0!3m2!1sen!2ssa!4v1709978814211!5m2!1sen!2ssa','Jeddah'),
    # Add more data as needed
]
 
# Define data to insert into the Livestream table 🛑 Date & time real
#Livestream_ID (INTEGER), Duration (REAL), Date (TEXT), Time (TEXT), Cam_ID (INTEGER), Num_of_Violation (INTEGER)
#🟠 Type of data and time actual or not?
Livestream_data = [
    (1, 12.40,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 1, 4),
    (2, 10.25,datetime.now().date().strftime('%d %b %Y'),datetime.now().time().strftime('%H:%M'), 2, 3),
    (3, 8.75,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 3, 6),
    (4, 14.50,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 4, 4),
    (5, 9.80,datetime.now().date().strftime('%d %b %Y'),datetime.now().time().strftime('%H:%M'), 5, 5),
    (6, 7.90,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 6, 1),
    (7, 11.20,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 7, 7),
    (8, 13.75,datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 8, 3),
    (9, 9.30, datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 9, 5),
    (10, 12.60, datetime.now().date().strftime('%d %b %Y'),datetime.now().time().strftime('%H:%M'), 10, 2),
    (11, 8.45, datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 11, 4),
    (12, 10.80, datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 12, 1),
    (13, 8.45, datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 13, 5),
    (14, 10.80, datetime.now().date().strftime('%d %b %Y'), datetime.now().time().strftime('%H:%M'), 14, 9),
]

 
# Define data to insert into the Violation table 🛑 Date & time real
#Violation_ID INTEGER, Violation_type TEXT, Video_Path TEXT, Date TEXT, Time TEXT, Livestream_ID INTEGER 
#🛑 ADD Video link 
Violation_data = [
    (1,'Vehicle', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 1),
    (2,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 2),
    (3,'Vehicle', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 3),
    (4,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 5),
    (5,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 3),
    (6,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 4), 
    (7,'Vehicle', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 2),
    (8,'Vehicle', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 6),
    (9,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 4),
    (10,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 4),
    (11,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 1),
    (12,'Vehicle', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 2),
    (13,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 7),
    (14,'Pedestrian', r'static\images\littering.mp4', datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3], 5),
]
 



#Ticket DATA
Ticket_data = [
    (1, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Vehicle', r'static\images\littering.mp4',1,1, 1),
    (2, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Pedestrian', r'static\images\littering.mp4',2,2, 2),
    (3, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Vehicle', r'static\images\littering.mp4',3,3, 3),
    (4, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Pedestrian', r'static\images\littering.mp4',5,4, 4),
    (5, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Pedestrian', r'static\images\littering.mp4',3,5, 5),
    (6, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Pedestrian', r'static\images\littering.mp4',4,6, 6), 
    (7, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Open','Vehicle', r'static\images\littering.mp4',2,7, 7),
    (8, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Vehicle', r'static\images\littering.mp4',6,8, 8),
    (9, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Pedestrian', r'static\images\littering.mp4',4,9, 9),
    (10, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Pedestrian', r'static\images\littering.mp4',4,10, 10),
    (11, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Pedestrian', r'static\images\littering.mp4',1,11, 11),
    (12, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Vehicle', r'static\images\littering.mp4',2,12, 12),
    (13, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Pedestrian', r'static\images\littering.mp4',7,13, 13),
    (14, datetime.now().date().strftime('%d/%m/%Y'), datetime.now().time().strftime('%I:%M:%S %p')[:-3],datetime.now().time().strftime('%Y-%m-%d %H:%M:%S'),'Closed','Pedestrian', r'static\images\littering.mp4',5,14, 14),
]



# Define data to insert into the camera-manage table 🛑 Date & time real
#Admin_ID INTEGER , Cam_ID INTEGER
camera_manage_data = [
    (1,1),
    (1,2),
    (2,3),
    (2,4),
    (3,5),
    (4,6),
    (5,7),
    (6,8),
    (12,9),
    (14,10),
    (13,11),
    (15,12),
    (16,13),
    (11,14),
    ]

# Define data to insert into the violation_manage table 🛑 Date & time real
#Admin_ID INTEGER , Violation_ID INTEGER
violation_manage_data = [
    (1,1),
    (1,2),
    (1,3),
    (1,4),
    (2,5),
    (2,6),
    (2,7),
    (2,8),
    (4,9),
    (3,10),
    (7,11),
    (5,12),
    (5,13),
    (5,14),
     ]
 
# Define data to insert into the Pedestrian table    
# Violation_ID INTEGER,Face_Image Text  
# 🛑 Add image data
# Define data to insert into the Pedestrian table
# Violation_ID INTEGER, Face_Image TEXT
# 🛑 Add image data
Pedestrian_data = [
    (1, 'static\\images\\car_palte.jpg'),
    (2, 'static\\images\\car_palte.jpg'),
    (3, 'static\\images\\car_palte.jpg'),  # Assuming this file is in the current directory
    (4, 'static\\images\\car_palte.jpg'),
    (5, 'static\\images\\car_palte.jpg'),
    (6, 'static\\images\\car_palte.jpg'),
    (7, 'static\\images\\car_palte.jpg'),
]
 
 

# Define data to insert into the Vehicle table    
# Violation_ID INTEGER,Plate_No Text  
# 🛑 Add image data
Vehicle_data = [
    (8,'static\\images\\car_palte.jpg'),
    (9,'static\\images\\car_palte.jpg'),
    (10,'static\\images\\car_palte.jpg'),
    (11,'static\\images\\car_palte.jpg'),
    (12,'static\\images\\car_palte.jpg'),
    (13,'static\\images\\car_palte.jpg'),
    (14,'static\\images\\car_palte.jpg'),
     ]
 
 

# Define SQL queries to insert data into tables
# ------------------------------------------------------------------------------
insert_Admin_query = "INSERT INTO Admin (Admin_ID, First_Name, Last_Name,Email,User_Name,Password,Phone_No) VALUES (?, ?, ?, ?, ? , ?, ?)"
insert_Camera_query = "INSERT INTO Camera (Cam_ID, Cam_IP, Status, Frame_Rate, Resolution, Location, City) VALUES (?, ?, ?, ?, ?, ?, ?)"
insert_Livestream_query = """INSERT INTO Livestream (Livestream_ID, Duration, Date, Time, Cam_ID, Num_of_Violation) VALUES (?, ?, ?, ?, ?, ?)"""
insert_violation_query = """INSERT INTO Violation (Violation_ID, Violation_type, Video_Path, Date, Time, Livestream_ID) VALUES (?, ?, ?, ?, ?, ?)"""


insert_Ticket_query = """INSERT INTO Ticket (Ticket_ID, Date, Time, Close_Date, Status,Violation_type ,Video_Path,Livestream_ID,Admin_ID, Violation_ID) VALUES (?, ?, ?, ?, ?, ?,?,?,?,?)"""




insert_camera_manage_query = """INSERT INTO camera_manage (Admin_ID, Cam_ID) VALUES (?, ?)"""
insert_violation_manage_query = """INSERT INTO violation_manage (Admin_ID, Violation_ID) VALUES (?, ?)"""
insert_pedestrian_query = """INSERT INTO Pedestrian (Violation_ID, Face_Image) VALUES (?, ?)""" #Data convert to binary
insert_Vehicle_query = """INSERT INTO Vehicle (Violation_ID, Plate_No) VALUES (?, ?)"""



# ------------------------------------------------------------------------------

# Check if the data already exists in the Admin table before insertion
existing_Admin_ids = [row[0] for row in cursor.execute("SELECT Admin_ID FROM Admin").fetchall()]
filtered_Admin_data = [(Admin_ID, First_Name, Last_Name,Email,User_Name,Password,Phone_No) for Admin_ID, First_Name, Last_Name,Email,User_Name,Password,Phone_No in Admin_data if Admin_ID not in existing_Admin_ids] 

# Insert filtered data into the Admin table
cursor.executemany(insert_Admin_query, filtered_Admin_data)

 
# Check if the data already exists in the Camera table before insertion
existing_Camera_ids = [row[0] for row in cursor.execute("SELECT Cam_ID FROM Camera").fetchall()]
filtered_Camera_data = [ (Cam_ID, Cam_IP, Status, Frame_Rate, Resolution, Location, City) for Cam_ID, Cam_IP, Status, Frame_Rate, Resolution, Location, City in Camera_data if Cam_ID not in existing_Camera_ids] 

# Insert filtered data into the Camera table
cursor.executemany(insert_Camera_query, filtered_Camera_data)

 
# Check if the data already exists in the Livestream table before insertion
existing_Livestream_ids = [row[0] for row in cursor.execute("SELECT Livestream_ID FROM Livestream").fetchall()]
filtered_Livestream_data = [(Livestream_ID, Duration, Date, Time, Cam_ID, Num_of_Violation) for Livestream_ID, Duration, Date, Time, Cam_ID, Num_of_Violation in Livestream_data if Livestream_ID not in existing_Livestream_ids]

# Insert filtered data into the Livestream table
cursor.executemany(insert_Livestream_query, filtered_Livestream_data)

# Check if the violation already exists in the Violation table before insertion
existing_violation_ids = [row[0] for row in cursor.execute("SELECT Violation_ID FROM Violation").fetchall()]
filtered_violation_data = [(Violation_ID, Violation_type, Video_Path, Date, Time, Livestream_ID) for Violation_ID, Violation_type, Video_Path, Date, Time, Livestream_ID in Violation_data if Violation_ID not in existing_violation_ids]

# Insert filtered data into the Violation table
cursor.executemany(insert_violation_query, filtered_violation_data)





#Ticket table
existing_Ticket_ids = [row[0] for row in cursor.execute("SELECT Ticket_ID FROM Ticket").fetchall()]
filtered_Ticket_data = [(Ticket_ID, Date, Time, Close_Date, Status,Violation_type,Video_Path,Livestream_ID,Admin_ID,Violation_ID) for Ticket_ID, Date, Time, Close_Date, Status,Violation_type,Video_Path,Livestream_ID,Admin_ID,Violation_ID in Ticket_data if Ticket_ID not in existing_Ticket_ids]

# Insert filtered data into the Ticket table
cursor.executemany(insert_Ticket_query, filtered_Ticket_data)



 
 
# Insert filtered data into the camera_manage table
cursor.executemany(insert_camera_manage_query, camera_manage_data)

# Insert filtered data into the Violation_manage table
cursor.executemany(insert_violation_manage_query, violation_manage_data)

 


# 🛑 Insert filtered data into the Pedestrain table
cursor.executemany(insert_pedestrian_query, Pedestrian_data )

# 🛑 Insert filtered data into the Vehicle table
cursor.executemany(insert_Vehicle_query, Vehicle_data)

 
 
# Commit the changes and close the connection
conn.commit()
conn.close()

''' 

 
# Define data to insert into the book table
book_data = [
    (1, 'John Doe', 'English', 'The Great Gatsby'),
    (2, 'Jane Smith', 'French', 'Les Misérables'),
    # Add more data as needed
]

# Define data to insert into the category table
category_data = [
    (1, 'Fiction'),
    (2, 'Classic'),
    # Add more data as needed
]

# Define SQL queries to insert data into tables
insert_book_query = "INSERT INTO book (id, author, language, title) VALUES (?, ?, ?, ?)"
insert_category_query = "INSERT INTO category (id, name) VALUES (?, ?)"

# Check if the data already exists in the book table before insertion
existing_book_ids = [row[0] for row in cursor.execute("SELECT id FROM book").fetchall()]
filtered_book_data = [(id, author, language, title) for id, author, language, title in book_data if id not in existing_book_ids]

# Insert filtered data into the book table
cursor.executemany(insert_book_query, filtered_book_data)

# Check if the data already exists in the category table before insertion
existing_category_ids = [row[0] for row in cursor.execute("SELECT id FROM category").fetchall()]
filtered_category_data = [(id, name) for id, name in category_data if id not in existing_category_ids]

# Insert filtered data into the category table
cursor.executemany(insert_category_query, filtered_category_data)

# Commit the changes and close the connection
conn.commit()
conn.close()
'''