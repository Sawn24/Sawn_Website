 

// -------------------date picker-------------------
$(function() {
    $("#datepicker").datepicker();
});


// -------------------notification-------------------

document.getElementById("notificationIcon").addEventListener("click", function () {
    var notificationList = document.getElementById("notificationList");
    if (notificationList.style.display === "none" || notificationList.style.display === "") {
        notificationList.style.display = "block";
    } else {
        notificationList.style.display = "none";
    }
});
// -------------------option-----------------------
document.addEventListener("DOMContentLoaded", function () {
    const dropdownToggle = document.getElementById("dropdownMenuLink");
    const dropdownMenu = document.querySelector(".dropdown-menu");

    dropdownToggle.addEventListener("click", function (event) {
        event.preventDefault(); // Prevent the default hyperlink behavior
        if (dropdownMenu.style.display === "none" || dropdownMenu.style.display === "") {
            dropdownMenu.style.display = "block";
        } else {
            dropdownMenu.style.display = "none";
        }
    });
});