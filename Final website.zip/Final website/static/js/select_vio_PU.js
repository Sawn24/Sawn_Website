var checkboxes = document.querySelectorAll(".item input[type='checkbox']");
function checkAll(myCheckbox){
    if(myCheckbox.checked == true){
        checkboxes.forEach(function(checkbox){
            checkbox.checked = true;
        });
    }
    else{
        checkboxes.forEach(function(checkbox){
            checkbox.checked = false;
        });
    }
}
function uncheckAll(){
    if (checkboxes.length > 0) {
        var firstCheckbox = checkboxes[0];
        firstCheckbox.checked  = false; 
    }      
}
//-----------------------✔ Added by GHADAH---------------------------
// Function to display the popup
function showPopup() {
  var popup = document.getElementById("popup-3");
  popup.style.display = "flex";
}

// Call the showPopup function when the page loads
window.addEventListener("DOMContentLoaded", function () {
  // Retrieve the success message by ID
  var successMessageElement = document.getElementById("success-message");
  // Check if the success message element exists and its text content is not empty
  if (successMessageElement && successMessageElement.textContent.trim() !== "") {
      // If success message is not empty, show the popup
      showPopup();
  }
});
//--------------------------------------------------

window.addEventListener("DOMContentLoaded", function () {
    var selectButton = document.querySelector(".select-btn");
    var list = document.getElementById("list");
  
    selectButton.addEventListener("click", function () {
      // Toggle the display of the list
      if (list.style.display === "flex") {
        list.style.display = "none";
      } else {
        list.style.display = "flex";
      }
    });
  });

  window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".close-button");
    var popup = document.getElementById("popup-2");
  
    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
  });

  window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".close-button2");
    var popup = document.getElementById("popup-3");
    
    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
  });
  
  /** 
  window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".send-button");
    var popup2 = document.getElementById("popup-2");
    var popup3 = document.getElementById("popup-3");
    closeButton.addEventListener("click", function () {
        popup3.style.display = "flex";
        popup2.style.display = "none";
    });
  });
*/
  window.addEventListener("DOMContentLoaded", function () {
    var sButton = document.getElementById("vio-select-btn");
    var popup = document.getElementById("popup-2");

    sButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});
