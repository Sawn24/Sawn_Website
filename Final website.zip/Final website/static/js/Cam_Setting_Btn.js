window.addEventListener("DOMContentLoaded", function () {
  var sButton = document.getElementById("Camera-Setting-btn");
  var popup = document.getElementById("popup-7");

  sButton.addEventListener("click", function (event) {
    event.preventDefault();
    popup.style.display = "flex";
  });
});

window.addEventListener("DOMContentLoaded", function () {
  var closeButton = document.querySelector(".close-button7");
  var popup = document.getElementById("popup-7");

  closeButton.addEventListener("click", function () {
    popup.style.display = "none";
  });
});

 
checkboxes2 = document.querySelectorAll(".delete-cam-continer input[type='checkbox']");
function checkAll2(myCheckbox) {
  if (myCheckbox.checked == true) {
    checkboxes2.forEach(function (checkbox) {
      checkbox.checked = true;
    });
  }
  else {
    checkboxes2.forEach(function (checkbox) {
      checkbox.checked = false;
    });
  }
}
function uncheckAll2() {
  if (checkboxes2.length > 0) {
    var firstCheckbox = checkboxes2[0];
    firstCheckbox.checked = false;
  }
}


checkboxes = document.querySelectorAll(".edit-cam-continer input[type='checkbox']");
function checkAll(myCheckbox) {
  if (myCheckbox.checked == true) {
    checkboxes.forEach(function (checkbox) {
      checkbox.checked = true;
    });
  }
  else {
    checkboxes.forEach(function (checkbox) {
      checkbox.checked = false;
    });
  }
}
function uncheckAll() {
  if (checkboxes.length > 0) {
    var firstCheckbox = checkboxes[0];
    firstCheckbox.checked = false;
  }
}


window.addEventListener("DOMContentLoaded", function () {
  var selectButton = document.querySelector(".delete-cam-continer .select-cam-text");
  var list = document.getElementById("delete-cam-list");

  selectButton.addEventListener("click", function () {
    // Toggle the display of the list
    if (list.style.display === "flex") {
      list.style.display = "none";
    } else {
      list.style.display = "flex";
    }
  });
});


window.addEventListener("DOMContentLoaded", function () {
  var selectButton = document.querySelector(".edit-cam-continer .select-cam-text");
  var list = document.getElementById("edit-cam-list");

  selectButton.addEventListener("click", function () {
    // Toggle the display of the list
    if (list.style.display === "flex") {
      list.style.display = "none";
    } else {
      list.style.display = "flex";
    }
  });
});

window.addEventListener("DOMContentLoaded", function () {
  var selectButton = document.getElementById("delete-cam-btn");
  var edit = document.getElementById("edit-cam-continer");
  var add = document.getElementById("add-cam-continer");
  var delete1 = document.getElementById("delete-cam-continer");

  selectButton.addEventListener("click", function () {
    // Toggle the display of the list
    if (delete1.style.display === "flex") {
      delete1.style.display = "none";
    } else {
      delete1.style.display = "flex";
      edit.style.display = "none";
      add.style.display = "none";
    }
  });
});

window.addEventListener("DOMContentLoaded", function () {
  var selectButton = document.getElementById("edit-cam-btn");
  var edit = document.getElementById("edit-cam-continer");
  var add = document.getElementById("add-cam-continer");
  var delete1 = document.getElementById("delete-cam-continer");

  selectButton.addEventListener("click", function () {
    // Toggle the display of the list
    if (edit.style.display === "flex") {
      edit.style.display = "none";
    } else {
      edit.style.display = "flex";
      delete1.style.display = "none";
      add.style.display = "none";
    }
  });
});

window.addEventListener("DOMContentLoaded", function () {
  var selectButton = document.getElementById("add-cam-btn");
  var edit = document.getElementById("edit-cam-continer");
  var add = document.getElementById("add-cam-continer");
  var delete1 = document.getElementById("delete-cam-continer");

  selectButton.addEventListener("click", function () {
    // Toggle the display of the list
    if (add.style.display === "flex") {
      add.style.display = "none";
    } else {
      add.style.display = "flex";
      edit.style.display = "none";
      delete1.style.display = "none";
    }
  });
});



