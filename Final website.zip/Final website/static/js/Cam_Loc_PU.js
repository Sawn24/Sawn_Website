/** Added by GHADAH */
window.addEventListener("DOMContentLoaded", function () {
    var detailsButtons = document.querySelectorAll(".details_btn");
    var popup = document.getElementById("popup-5");
    var closeButton = popup.querySelector(".close-button4");
    var cityElement = popup.querySelector("#city");
    var statusElement = popup.querySelector("#status");
    var mapIframe = popup.querySelector("#map-iframe");

    detailsButtons.forEach(function(button) {
        button.addEventListener("click", function (event) {
            event.preventDefault();

            // Get data attributes from the clicked button
            var city = button.getAttribute("data-city-id");
            var status = button.getAttribute("data-status-id");
            var locationSrc = button.getAttribute("data-location-src");

            // Update popup content with the data
            cityElement.innerText = city;
            statusElement.innerText = status;
            mapIframe.src = locationSrc;

            // Show the popup
            popup.style.display = "flex";
        });
    });

    // Close popup when close button is clicked
    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});


/**window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("location_details");
    var popup = document.getElementById("popup-5");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("location_details2");
    var popup = document.getElementById("popup-5");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("location_details3");
    var popup = document.getElementById("popup-5");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".popup5 .content .close-button4");
    var popup = document.getElementById("popup-5");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});*/
