/** ✔ Added by GHADAH */
window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Sbtn");
    var searchInput = document.getElementById("searchInput");
    var popup = document.getElementById("popup-1");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();

        // Check if the input value is a number
        if (!isNaN(searchInput.value) && searchInput.value.trim() !== "") {
             
            // Fetch violation details from Flask route
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "/GuestViolation", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        var data = JSON.parse(xhr.responseText);
                        console.log("Fetched data:", data);

                        if (data) {
                            // Update violation details in the popup using fetched data
                            //Violation ID, Violation Type, Violator Identity, Location, Date, Time
                            var violationID = data[0]['Ticket_ID'];
                            var violationType =data[0]['Violation_type'];
                            var violationLocation = data[0]['Location'];
                            var videoDate = data[0]['Date'];
                            var videoTime = data[0]['Time'];
                            var videoPath = data[0]['Video_Path'];
                            var violationIdentity = data[0]['Face_Image'];

                            if (violationIdentity==null) {
                                var violationType = data[0]['Plate_No'];   
                            }  

                            document.getElementById("violationID").innerText = violationID;
                            document.getElementById("violationType").innerText = violationType;
                            // 🛑 violator identity
                            document.getElementById("violationIdentity").src = violationIdentity;
                            document.getElementById("violationLocation").src = violationLocation;
                            document.getElementById("violationDate").innerText = videoDate;
                            document.getElementById("violationTime").innerText = videoTime;
                            

                            // Update video source and download link
                            var videoPlayer = document.getElementById("videoPlayer");
                            videoPlayer.setAttribute("src", videoPath);
                            var downloadLink = document.getElementById("downloadLink");
                            downloadLink.setAttribute("href", videoPath);

                            // Display the popup
                            popup.style.display = "flex";
                        }
                    } else {
                        // Handle HTTP errors
                        console.error("HTTP error:", xhr.status);
                        // Display an error message to the user
                        alert("Failed to fetch data. Please try again later.");
                    }
                }
            };
            xhr.send("TicketID=" + searchInput.value);

            
        } else {
            // Alert the user if the input is not a number or is empty
            alert("Please enter a valid number in the search input.");
        }
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".pg-close-button");
    var popup = document.getElementById("popup-1");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});

function showLocationPopup() {
    document.getElementById("Location-popup").style.display = "block";
}

function hideLocationPopup(event) {
    if (event.target.id === "Location-popup") {
        document.getElementById("Location-popup").style.display = "none";
    }
}


function showViolatorIdentityPopup() {
    document.getElementById("ViolatorIdentity-popup").style.display = "block";
}

function hideViolatorIdentityPopup(event){
    if (event.target.id === "ViolatorIdentity-popup") {
        document.getElementById("ViolatorIdentity-popup").style.display = "none";
    }
}
































/**window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Sbtn");
    var searchInput = document.getElementById("searchInput");
    var popup = document.getElementById("popup-1");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();

        // Check if the input value is a number
        if (!isNaN(searchInput.value) && searchInput.value.trim() !== "") {
            // Display the popup if the input is a number
            popup.style.display = "flex";
        } else {
            // Alert the user if the input is not a number or is empty
            alert("Please enter a valid number in the search input.");
        }
    });
});


window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".pg-close-button");
    var popup = document.getElementById("popup-1");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});


function showImagePopup() {
    document.getElementById("image-popup").style.display = "block";
}

function hideImagePopup(event) {
    if (event.target.id === "image-popup") {
        document.getElementById("image-popup").style.display = "none";
    }
}

*/