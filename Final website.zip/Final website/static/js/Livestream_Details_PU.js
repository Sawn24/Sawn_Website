

window.addEventListener("DOMContentLoaded", function () {
    var searchButtons = document.querySelectorAll(".livestream-content");
    var popup = document.getElementById("popup-6");
    var violationNumberSpan = document.getElementById("violationNumber");
    var CameraIDSpan = document.getElementById("CameraID");
    var Locationframe = document.getElementById("violationLocation");
    var DateSpan = document.getElementById("Date");
    var TimeSpan = document.getElementById("Time");
    var DurationSpan = document.getElementById("Duration");
    var LivestreamIDSpan = document.getElementById("LivestreamID");


    searchButtons.forEach(function (button) {
        button.addEventListener("click", function (event) {
            event.preventDefault();

            var cameraIP = button.querySelector("input[name='CameraIP[]']").value;

            fetch("/IPsearch", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ cameraIP: [cameraIP] })  // Send an array of a single camera IP
            })
            .then(response => response.json())
            .then(data => {
                // Access the 'Num_of_Violation' of the first row, assuming there's data returned
                if (data.length > 0) {
                    LivestreamIDSpan.innerText=data[0].Livestream_ID;
                    violationNumberSpan.innerText = data[0].Num_of_Violation;
                    CameraIDSpan.innerText=data[0].Cam_ID;
                    Locationframe.src = data[0].Location;
                    DateSpan.innerText=data[0].Date;
                    TimeSpan.innerText = data[0].Time;
                    DurationSpan.innerText=data[0].Duration;
                    popup.style.display = "flex";
                }
            })
            .catch(error => console.error('Error:', error));
        });
    });

    var closeButton = document.querySelector('.close-button5');
    closeButton.addEventListener('click', function() {
        popup.style.display = "none";
    });
});






function showLocationPopup() {
    document.getElementById("Location-popup").style.display = "block";
}

function hideLocationPopup(event) {
    if (event.target.id === "Location-popup") {
        document.getElementById("Location-popup").style.display = "none";
    }
}















/*

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details2");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details3");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details4");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details5");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details6");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details7");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details8");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});


window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("Livestream_Details9");
    var popup = document.getElementById("popup-6");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});







window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".popup6 .content .close-button5");
    var popup = document.getElementById("popup-6");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});
*/