const openedBtn = document.getElementById('opened-btn');
const closedBtn = document.getElementById('closed-btn');

openedBtn.classList.add('active');

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("opened-btn");
    var close = document.getElementById("Closedtable");
    var open = document.getElementById("OpenedTable");


    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        close.style.display = "none";
        open.style.display = "Table";

        openedBtn.classList.add('active');
        closedBtn.classList.remove('active');
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("closed-btn");
    var close = document.getElementById("Closedtable");
    var open = document.getElementById("OpenedTable");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        open.style.display = "none";
        close.style.display = "Table";

        closedBtn.classList.add('active');
        openedBtn.classList.remove('active');

    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("details_btn");
    var popup = document.getElementById("popup-4");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("details_btn2");
    var popup = document.getElementById("popup-4");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".close-button3");
    var popup = document.getElementById("popup-4");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});



function showImagePopup() {
    document.getElementById("image-popup").style.display = "block";
}

function hideImagePopup(event) {
    if (event.target.id === "image-popup") {
        document.getElementById("image-popup").style.display = "none";
    }
}

