//*✔ The first script Edited by GHADAH 
window.addEventListener("DOMContentLoaded", function () {
    var detailsButtons = document.querySelectorAll(".details_btn");
    var popup = document.getElementById("popup-4");
    var closeButton = popup.querySelector(".close-button3");
    var violationIdElement = popup.querySelector("#violation-id");
    var violationTypeElement = popup.querySelector("#violation-type");
    var videoPlayer = popup.querySelector("#video-player");

    detailsButtons.forEach(function(button) {
        button.addEventListener("click", function (event) {
            event.preventDefault();

            // Get data attributes from the clicked button
            //plate-identit-src="{{ row['Plate_No'] }} " face-identit-src="{{ row['Face_Image'] }}"
            var violationId = button.getAttribute("data-vio-id");
            var violationType = button.getAttribute("data-vio-type");
            var videoSrc = button.getAttribute("data-video-src");
            var violationIdentity = button.getAttribute("plate-identity-src");
           
            if (violationIdentity.match("None")) {
                violationIdentity = button.getAttribute("face-identity-src");  
            } 
 


            // Update popup content with the data
            violationIdElement.innerText = violationId;
            violationTypeElement.innerText = violationType;
            videoPlayer.src = videoSrc;
            document.getElementById("violationIdentity").src = violationIdentity;



            // Show the popup
            popup.style.display = "flex";
        });
    });

    // Close popup when close button is clicked
    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});



function showViolatorIdentityPopup() {
    document.getElementById("ViolatorIdentity-popup").style.display = "block";
}

function hideViolatorIdentityPopup(event){
    if (event.target.id === "ViolatorIdentity-popup") {
        document.getElementById("ViolatorIdentity-popup").style.display = "none";
    }
}
























/** 



window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("details_btn");
    var popup = document.getElementById("popup-4");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});

window.addEventListener("DOMContentLoaded", function () {
    var searchButton = document.getElementById("details_btn2");
    var popup = document.getElementById("popup-4");

    searchButton.addEventListener("click", function (event) {
        event.preventDefault();
        popup.style.display = "flex";
    });
});


window.addEventListener("DOMContentLoaded", function () {
    var closeButton = document.querySelector(".close-button3");
    var popup = document.getElementById("popup-4");

    closeButton.addEventListener("click", function () {
        popup.style.display = "none";
    });
});

function showImagePopup() {
    document.getElementById("image-popup").style.display = "block";
}

function hideImagePopup(event) {
    if (event.target.id === "image-popup") {
        document.getElementById("image-popup").style.display = "none";
    }
}
*/