document.addEventListener('DOMContentLoaded', function() {
    var loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent form submission

            var username = document.getElementById('usernameInput').value;
            var password = document.getElementById('passwordInput').value;

            if (username === 'Admin' && password === 'A') {
                console.log("Valid username or password. ");

                // Redirect to another page after successful login
                window.location.assign("Home-page.html")  ; // Replace with your desired URL
            } else {
                console.log("Invalid username or password. Please try again. ");
                alert('Invalid username or password. Please try again.');
            }
        });
    } else {
        console.error('Login form element not found.');
    }
});
