
document.addEventListener('DOMContentLoaded', function() {
  // Your code here


  document.addEventListener('DOMContentLoaded', function() {
    // Get the edit button and text-box elements
    const editButton = document.querySelector('.editbutton');
    const textBoxes = document.querySelectorAll('.text-box');
  
    // Add click event listener to the edit button
    editButton.addEventListener('click', function(event) {
      event.preventDefault();
      // Toggle the text of the button
      editButton.textContent = editButton.textContent === 'Edit' ? 'Save'  : 'Edit';
     
      // Loop through the text-box elements
      textBoxes.forEach(function(textBox) {
        textBox.readOnly = !textBox.readOnly;
        textBox.classList.toggle('editable');
      });
    });
  });

});


/*
//this is the orginal code by waad 
// Get the edit button and text-box elements
const editButton = document.querySelector('.editbutton');
const textBoxes = document.querySelectorAll('.text-box');

// Add click event listener to the edit button
editButton.addEventListener('click', function() {
  // Toggle the text of the button
  editButton.textContent = editButton.textContent === 'Edit' ? 'Save' : 'Edit';
  
  // Loop through the text-box elements
  textBoxes.forEach(function(textBox) {
    textBox.readOnly = !textBox.readOnly;
    textBox.classList.toggle('editable');
  });
});

*/
